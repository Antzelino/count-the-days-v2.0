#!/usr/bin/python

import datetime

#add your date to count down to. (year, month, day)
diff = datetime.datetime(1970, 1, 1) - datetime.datetime.today()
print diff.days +1,
