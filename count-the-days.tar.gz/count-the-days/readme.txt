1. Open the ".count-the-days" folder and check the .sh and .py files have executable permissions.

2. Edit the count-the-days.py file to use the date you want to count down to.

3. Move the ".count-the-days" folder to your home directory.

4. To run execute start.sh script.
   				or
   in the terminal run...
   conky -c ~/.count-the-days/count-the-days.conkyrc

5. To autostart add:
   sh -c "conky -p 15 -c ~/.count-the-days/count-the-days.conkyrc" 
   in startup applications. This will pause the start of conky for 15 secs to allow the window manager to load first.

