#!/bin/bash

conky -c ~/.count-the-days/count-the-days.conkyrc
